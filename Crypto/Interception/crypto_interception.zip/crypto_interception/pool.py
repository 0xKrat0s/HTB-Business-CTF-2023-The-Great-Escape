GREET = [
    'Is there an emergency?',
    'How you doing?',
    'Hey!'
]

ANS = [
    'Great news, but use this channel responsibly.',
    'I will inform the governor.',
    'Bye!'
]